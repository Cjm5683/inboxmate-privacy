# Changelog

## 1.0.1 — 2026-10-23

Documentation accuracy pass. `worker.js` behaviour is unchanged.

- README: state plainly that DeepSeek is the out-of-the-box default, Claude is a
  one-line config change, and OpenAI/GPT needs the `callLLM()` tweak from
  `CUSTOMIZE.md` (it uses the Chat Completions shape, not `/messages`)
- README: drop the "worth buying" wording — the kit is a free download
- README: custom implementations are "available on request" rather than sold
- Landing page: corrected the secret names, the auth header, the endpoint path
  and the CORS location so the written steps match the code

## 1.0.0 — 2026-10-22

Initial release.

- Cloudflare Worker that proxies Claude / DeepSeek / OpenAI-compatible APIs
- Secrets via `wrangler secret put` (never in code)
- CORS allow-list with configurable origins
- Shared client-secret auth with constant-time comparison
- Per-IP rate limiting (60 req/min, in-memory)
- Request body size limit (20 KB) and control-character sanitization
- Security response headers on every response
- `/health` endpoint for deploy verification
- `DEPLOY.md` and `CUSTOMIZE.md` guides
- MIT license
