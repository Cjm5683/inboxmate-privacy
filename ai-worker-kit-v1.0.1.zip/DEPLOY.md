# Deploy in ~10 minutes

## 0. Prerequisites

- A Cloudflare account (the free plan is fine to start)
- Node.js 18+ — check with `node -v`
- The Cloudflare CLI:

```bash
npm install -g wrangler
```

## 1. Log in to Cloudflare

```bash
npx wrangler login
```

A browser tab opens; approve the request.

## 2. Put your secrets in

Never put an API key in `worker.js` or in this file. Use secrets.

```bash
# Your LLM key — Claude, DeepSeek or OpenAI
npx wrangler secret put LLM_API_KEY

# A random string your frontend will send back
npx wrangler secret put CLIENT_SECRET
```

Generate a good one:

```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

## 3. Edit the config block

Open `worker.js` and change only the block marked `CONFIGURATION`:

```js
const ALLOWED_ORIGINS = [
  'https://your-client-domain.com',
  'chrome-extension://YOUR_EXT_ID',
];
const LLM_BASE_URL = 'https://api.deepseek.com/anthropic/v1/messages';
const DEFAULT_MODEL = 'deepseek-chat';
```

If you use Claude instead:

```js
const LLM_BASE_URL = 'https://api.anthropic.com/v1/messages';
const DEFAULT_MODEL = 'claude-sonnet-4-20250514';
```

## 4. Deploy

```bash
npx wrangler deploy
```

Wrangler prints your URL, e.g. `https://ai-worker-backend.your-name.workers.dev`.

## 5. Verify

```bash
# health check
curl https://<your-worker>.workers.dev/health
# {"status":"ok","service":"ai-worker-backend"}

# real call (replace the secret with your CLIENT_SECRET)
curl -X POST https://<your-worker>.workers.dev/v1/chat \
  -H "Content-Type: application/json" \
  -H "X-Client-Secret: <your CLIENT_SECRET>" \
  -d '{"messages":[{"role":"user","content":"Say hello in 3 words"}]}'
```

If you get `{"error":"unauthorized"}` the secret does not match. If you get
`{"error":"llm_unavailable"}` check the provider URL/model and that the key is valid.
If you get `{"error":"rate_limited"}` you hit the per-IP limit (60/min) — raise
`RATE_LIMIT_PER_IP` in `worker.js` or wait a minute.

## 6. Point your frontend at it

```javascript
const res = await fetch('https://<your-worker>.workers.dev/v1/chat', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'X-Client-Secret': '<CLIENT_SECRET>',
  },
  body: JSON.stringify({ messages: [{ role: 'user', content: 'Hello' }] }),
});
```

Your frontend's origin must be listed in `ALLOWED_ORIGINS`, or CORS will block it.

## Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| `401 unauthorized` | secret mismatch | `npx wrangler secret put CLIENT_SECRET` and update your frontend |
| `403` in browser console | origin not allowed | add your domain to `ALLOWED_ORIGINS` and redeploy |
| `429 rate_limited` | too many requests from one IP | raise `RATE_LIMIT_PER_IP` |
| `503 llm_unavailable` | provider error | check `LLM_BASE_URL` / `DEFAULT_MODEL` / key quota |
| Worker 404 | wrong path | endpoints are `/health` and `/v1/chat` only |
| `durable object` errors | none expected | this kit uses in-memory rate limiting only |

## Custom domain

After the first successful deploy:

```bash
npx wrangler deploy --dry-run   # sanity check
```

Then add a `[[routes]]` block to `wrangler.toml` and redeploy.
