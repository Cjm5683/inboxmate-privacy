// ============================================================================
// AI Worker Backend Kit — production LLM proxy for Cloudflare Workers
// https://<your-worker>.workers.dev
//
// WHAT THIS IS
//   Frontend  ->  Cloudflare Worker  ->  LLM API (Claude / DeepSeek / GPT)
//   Your API key lives only in a Worker secret. It is never sent to the browser.
//
// SECURITY BASELINE (already implemented — don't remove it)
//   - API key stored as a Worker secret, never in code
//   - CORS allow-list: only YOUR domain / extension can call it
//   - Shared client secret, compared in constant time (timing-attack safe)
//   - Per-IP rate limiting so nobody can burn through your LLM bill
//   - Request body size limit + security headers + input sanitization
//
// BEFORE YOU DEPLOY — set two secrets (never put them in the code):
//   npx wrangler secret put LLM_API_KEY     # your Claude / DeepSeek / OpenAI key
//   npx wrangler secret put CLIENT_SECRET   # a random string shared with your frontend
// ============================================================================

// ---- 1. CONFIGURATION — this is the only block you need to edit --------------
const ALLOWED_ORIGINS = [
  'https://your-client-domain.com',   // your website
  'chrome-extension://YOUR_EXT_ID',   // your Chrome extension, if any
];
const MAX_BODY_BYTES = 20 * 1024;          // 20 KB — blocks oversized payloads
const RATE_LIMIT_PER_IP = 60;              // max requests per IP per minute
const RATE_LIMIT_WINDOW_MS = 60 * 1000;

// LLM provider settings.
// Defaults target DeepSeek's Anthropic-compatible endpoint (cheapest).
// To switch provider, change LLM_BASE_URL + DEFAULT_MODEL (see PROVIDERS below).
const LLM_BASE_URL = 'https://api.deepseek.com/anthropic/v1/messages';
const DEFAULT_MODEL = 'deepseek-chat';
const DEFAULT_MAX_TOKENS = 1024;
const DEFAULT_SYSTEM_PROMPT =
  'You are a helpful assistant. Answer concisely and accurately.';

/*
 PROVIDERS — pick one
 --------------------
 Anthropic (Claude)
   LLM_BASE_URL = 'https://api.anthropic.com/v1/messages'
   DEFAULT_MODEL = 'claude-sonnet-4-20250514'
   headers: 'x-api-key' + 'anthropic-version: 2023-06-01'   (already set below)

 DeepSeek (Anthropic-compatible, cheapest)
   LLM_BASE_URL = 'https://api.deepseek.com/anthropic/v1/messages'
   DEFAULT_MODEL = 'deepseek-chat'

 OpenAI (GPT) — uses the Chat Completions shape, not /messages
   LLM_BASE_URL = 'https://api.openai.com/v1/chat/completions'
   DEFAULT_MODEL = 'gpt-4o-mini'
   ... and adjust callLLM()'s request body + the response you read
   (the Anthropic-compatible shape returns { content: [{ type:'text', text }] })
*/
// ----------------------------------------------------------------------------

function json(data, status = 200, headers = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff',
      'X-Frame-Options': 'DENY',
      'Referrer-Policy': 'no-referrer',
      ...headers,
    },
  });
}

function corsHeaders(origin) {
  const allowed = ALLOWED_ORIGINS.includes(origin) ? origin : ALLOWED_ORIGINS[0];
  return {
    'Access-Control-Allow-Origin': allowed,
    'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, X-Client-Secret',
    'Access-Control-Max-Age': '86400',
  };
}

function getSecret(env, name) {
  if (!env[name]) throw new Error(`missing_${name.toLowerCase()}`);
  return env[name];
}

// Constant-time comparison of the shared client secret (timing-attack safe).
async function secretsEqual(a, b) {
  const enc = new TextEncoder();
  const [ha, hb] = await Promise.all([
    crypto.subtle.digest('SHA-256', enc.encode(a)),
    crypto.subtle.digest('SHA-256', enc.encode(b)),
  ]);
  const ba = new Uint8Array(ha);
  const bb = new Uint8Array(hb);
  if (ba.length !== bb.length) return false;
  let diff = 0;
  for (let i = 0; i < ba.length; i++) diff |= ba[i] ^ bb[i];
  return diff === 0;
}

// ---- Per-IP rate limiting (in-memory; fine on the free tier) ----------------
// For high traffic, swap this for a Durable Object or KV.
const hits = new Map(); // ip -> { count, resetAt }
function isRateLimited(ip) {
  const now = Date.now();
  let entry = hits.get(ip);
  if (!entry || now > entry.resetAt) {
    entry = { count: 0, resetAt: now + RATE_LIMIT_WINDOW_MS };
    hits.set(ip, entry);
  }
  entry.count += 1;
  if (hits.size > 10000) hits.clear(); // simple guard against unbounded memory
  return entry.count > RATE_LIMIT_PER_IP;
}

// ---- Call the LLM (Anthropic-compatible /messages endpoint) ----------------
async function callLLM(env, { messages, maxTokens, model, system }) {
  const apiKey = getSecret(env, 'LLM_API_KEY');
  const response = await fetch(LLM_BASE_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: model || DEFAULT_MODEL,
      max_tokens: maxTokens || DEFAULT_MAX_TOKENS,
      system: system || DEFAULT_SYSTEM_PROMPT,
      messages,
    }),
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(`llm_error:${response.status}`);
  }
  return body;
}

// ---- Input sanitization: length limit + strip control characters -----------
function sanitizeText(value, maxLength = 8000) {
  const str = String(value ?? '');
  return str
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '')
    .slice(0, maxLength);
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const origin = request.headers.get('Origin') || '';

    // CORS preflight
    if (request.method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: corsHeaders(origin) });
    }

    // Health check — handy for confirming the deploy worked
    if (url.pathname === '/health') {
      return json({ status: 'ok', service: 'ai-worker-backend' }, 200, corsHeaders(origin));
    }

    // Only /v1/chat is handled
    if (url.pathname !== '/v1/chat' || request.method !== 'POST') {
      return json({ error: 'not_found' }, 404, corsHeaders(origin));
    }

    // 1. Verify the shared secret so direct calls are rejected
    const clientSecret = request.headers.get('X-Client-Secret') || '';
    if (!(await secretsEqual(clientSecret, getSecret(env, 'CLIENT_SECRET')))) {
      return json({ error: 'unauthorized' }, 401, corsHeaders(origin));
    }

    // 2. Rate limit
    const ip = request.headers.get('CF-Connecting-IP') || 'unknown';
    if (isRateLimited(ip)) {
      return json({ error: 'rate_limited' }, 429, corsHeaders(origin));
    }

    // 3. Request body size limit
    const contentLength = Number(request.headers.get('Content-Length') || '0');
    if (contentLength > MAX_BODY_BYTES) {
      return json({ error: 'payload_too_large' }, 413, corsHeaders(origin));
    }

    let body;
    try {
      body = await request.json();
    } catch {
      return json({ error: 'invalid_json' }, 400, corsHeaders(origin));
    }

    // 4. Sanitize input and normalize it into the LLM's message format
    const messages = Array.isArray(body.messages)
      ? body.messages.slice(0, 20).map((m) => ({
          role: m?.role === 'user' || m?.role === 'assistant' ? m.role : 'user',
          content: sanitizeText(m?.content),
        }))
      : [{ role: 'user', content: sanitizeText(body.prompt || body.message) }];

    if (!messages.length || !messages[0].content) {
      return json({ error: 'empty_prompt' }, 400, corsHeaders(origin));
    }

    // 5. Call the LLM and pass the result straight back to the frontend
    try {
      const result = await callLLM(env, {
        messages,
        maxTokens: body.max_tokens,
        model: body.model,
        system: body.system ? sanitizeText(body.system, 2000) : undefined,
      });
      return json(result, 200, corsHeaders(origin));
    } catch (error) {
      console.error(JSON.stringify({ message: 'llm_call_failed', error: String(error) }));
      return json({ error: 'llm_unavailable' }, 503, corsHeaders(origin));
    }
  },
};
