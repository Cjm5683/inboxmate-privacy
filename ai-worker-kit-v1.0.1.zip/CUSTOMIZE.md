# Customization guide

## Switch LLM provider

Edit the config block at the top of `worker.js`.

### Anthropic (Claude)

```js
const LLM_BASE_URL = 'https://api.anthropic.com/v1/messages';
const DEFAULT_MODEL = 'claude-sonnet-4-20250514';
```

### DeepSeek (cheapest, Anthropic-compatible)

```js
const LLM_BASE_URL = 'https://api.deepseek.com/anthropic/v1/messages';
const DEFAULT_MODEL = 'deepseek-chat';
```

### OpenAI (GPT)

OpenAI uses the Chat Completions shape, so `callLLM()` needs a different body
and you read a different response field:

```js
const LLM_BASE_URL = 'https://api.openai.com/v1/chat/completions';
const DEFAULT_MODEL = 'gpt-4o-mini';
```

```js
// inside callLLM()
body: JSON.stringify({
  model: model || DEFAULT_MODEL,
  max_tokens: maxTokens || DEFAULT_MAX_TOKENS,
  messages: [{ role: 'system', content: system || DEFAULT_SYSTEM_PROMPT }, ...messages],
}),
headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${apiKey}` },
```

and read `data.choices?.[0]?.message?.content` instead of
`data.content?.[0]?.text`.

## Change the system prompt

```js
const DEFAULT_SYSTEM_PROMPT =
  'You are Acme Support. Answer in one short sentence. If you do not know, say so.';
```

You can also override it per request:

```json
{ "messages": [{"role":"user","content":"hi"}], "system": "You are a pirate." }
```

## Add streaming

Replace the final `return json(result, ...)` with a streaming response:

```js
const upstream = await fetch(LLM_BASE_URL, { /* same as above */ });
return new Response(upstream.body, {
  headers: { 'Content-Type': 'text/event-stream', ...corsHeaders(origin) },
});
```

## Add a chat UI

The frontend only needs two things: the Worker URL and the shared secret.

```html
<div id="log"></div>
<form id="f">
  <input id="q" placeholder="Ask something" autocomplete="off" />
  <button>Send</button>
</form>
<script>
const WORKER = 'https://<your-worker>.workers.dev';
const SECRET = '<CLIENT_SECRET>'; // server-side only
const log = document.getElementById('log');
document.getElementById('f').onsubmit = async (e) => {
  e.preventDefault();
  const input = document.getElementById('q');
  const text = input.value.trim();
  if (!text) return;
  input.value = '';
  log.innerHTML += `<div><b>You:</b> ${text}</div>`;
  const r = await fetch(WORKER + '/v1/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-Client-Secret': SECRET },
    body: JSON.stringify({ messages: [{ role: 'user', content: text }] }),
  });
  const d = await r.json();
  log.innerHTML += `<div><b>AI:</b> ${d.content?.[0]?.text ?? JSON.stringify(d)}</div>`;
};
</script>
```

## Use it from a Chrome extension

1. Put the Worker URL and secret in the **background service worker**, never in
   a content script or a page.
2. Add your extension id to `ALLOWED_ORIGINS` as
   `chrome-extension://<extension-id>` and redeploy.
3. From a content script, send a message to the background worker and let the
   background worker do the fetch.

## Raise the rate limit or share state across instances

`RATE_LIMIT_PER_IP` is per-isolate and in-memory. For higher traffic or global
state, move the counter into a Durable Object or KV — the rest of the file
stays the same.

## Change the model per request

```json
{ "messages": [{"role":"user","content":"hi"}], "model": "claude-opus-4-20250514" }
```

## Tune token limits

```json
{ "messages": [{"role":"user","content":"hi"}], "max_tokens": 4096 }
```

## Add your own endpoints

Copy the `/health` block inside the `fetch` handler and add a new `if`:

```js
if (url.pathname === '/v1/summarize') {
  // ... your logic
}
```
