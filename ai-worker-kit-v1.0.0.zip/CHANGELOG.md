# Changelog

## 1.0.0 — 2026-10-22

Initial release.

- Cloudflare Worker that proxies Claude / DeepSeek / OpenAI-compatible APIs
- Secrets via `wrangler secret put` (never in code)
- CORS allow-list with configurable origins
- Shared client-secret auth with constant-time comparison
- Per-IP rate limiting (60 req/min, in-memory)
- Request body size limit (20 KB) and control-character sanitization
- Security response headers on every response
- `/health` endpoint for deploy verification
- `DEPLOY.md` and `CUSTOMIZE.md` guides
- MIT license
