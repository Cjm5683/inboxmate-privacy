# AI Worker Backend Kit

**Deploy a production AI chat / agent backend on Cloudflare Workers in about 10 minutes.**

Your LLM API key never reaches the browser. CORS allow-list, per-IP rate limiting, shared-secret auth, request size limits, security headers and input sanitization are already wired in — you edit one config block and deploy.

Works with **Claude (Anthropic)**, **DeepSeek**, **OpenAI / GPT**, and any other Anthropic-compatible endpoint. A browser-extension frontend and a normal website both work out of the box.

---

## What's in the box

| File | What it is |
|------|------------|
| `worker.js` | The complete Worker. One config block at the top; the rest is the production security baseline. |
| `wrangler.toml` | Cloudflare config, already set up. |
| `DEPLOY.md` | Step-by-step deploy + verification. ~10 minutes, copy/paste commands. |
| `CUSTOMIZE.md` | How to switch providers, change the system prompt, add streaming, add a chat UI. |
| `CHANGELOG.md` | Version history. |
| `LICENSE` | MIT — use it in commercial client projects. |

---

## Quick start

```bash
# 1. install the Cloudflare CLI (skip if you have it)
npm install -g wrangler

# 2. log in
npx wrangler login

# 3. put your secrets in (never hardcode them)
npx wrangler secret put LLM_API_KEY
npx wrangler secret put CLIENT_SECRET

# 4. edit the config block at the top of worker.js
#    - ALLOWED_ORIGINS  -> your domain
#    - LLM_BASE_URL / DEFAULT_MODEL -> your provider

# 5. deploy
npx wrangler deploy

# 6. verify
curl https://<your-worker>.workers.dev/health
# {"status":"ok","service":"ai-worker-backend"}
```

Then call it from your frontend:

```javascript
const res = await fetch('https://<your-worker>.workers.dev/v1/chat', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'X-Client-Secret': '<the same CLIENT_SECRET you set>',
  },
  body: JSON.stringify({
    messages: [{ role: 'user', content: 'Hello' }],
  }),
});
const data = await res.json();
console.log(data.content?.[0]?.text);
```

> The client secret belongs **server-side only** (your backend, a serverless function, or a Chrome extension's background service worker). Never hardcode it in a public web page.

---

## The security baseline (why this is worth buying)

Most "AI backend" snippets in circulation are a 20-line proxy that leaks your API key to the browser and lets anyone on the internet drain your account. This one ships with:

- **Secrets stay server-side.** `LLM_API_KEY` and `CLIENT_SECRET` are Worker secrets, never in code and never sent to the client.
- **CORS allow-list.** Only the origins you list can call it.
- **Shared-secret auth** with constant-time comparison (no timing attacks).
- **Per-IP rate limiting** so a single client can't run up your bill.
- **Request body size limit** and **control-character stripping** on input.
- **Security response headers** (`X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy`, no-store).
- **Sanitized error output** — upstream failures return a generic error, details go to your logs, not to the caller.

---

## Use cases

- AI chat widget embedded in a website
- Chrome extension talking to an LLM without exposing a key
- Internal tool: a single front door for Claude / DeepSeek / GPT that you can swap models on
- A starting point for a custom agent API (add tools, RAG, or a Durable Object for shared rate-limit state)

---

## Requirements

- A Cloudflare account (the free Workers plan is enough to start)
- Node.js 18+ and the `wrangler` CLI
- An API key from Claude, DeepSeek or OpenAI

---

## License

MIT — see `LICENSE`. Use it in unlimited commercial client projects.

Questions or need a customized version (streaming, a chat UI, a Durable Object rate limiter, payment gating)? The seller provides custom implementation and deployment on request.
